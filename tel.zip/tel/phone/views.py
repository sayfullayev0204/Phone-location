# views.py
from django.shortcuts import render
import phonenumbers
from phonenumbers import geocoder, carrier
from opencage.geocoder import OpenCageGeocode
import folium

def phone_location(request):
    if request.method == 'POST':
        # Get the phone number from the form
        number = request.POST.get('phone_number', '')
        
        # Continue with the rest of the code as before
        parsed_number = phonenumbers.parse(number, "en")
        location = geocoder.description_for_number(parsed_number, 'en')
        service_provider = phonenumbers.parse(number)
        carrier_info = carrier.name_for_number(service_provider, "en")
        country = geocoder.country_name_for_number(parsed_number, "en")

        key = '0ebdf19437ce4eaf8aba8abf6eee7745'
        geocoder_opencage = OpenCageGeocode(key)
        query = str(location)
        results = geocoder_opencage.geocode(query)
        lat = results[0]['geometry']['lat']
        lng = results[0]['geometry']['lng']

        # Create a Folium map and add a marker for the location
        my_map = folium.Map(location=[lat, lng], zoom_start=9)
        
        # Modify the popup content to include carrier info and country name
        popup_content = f"{location}<br>Country: {country}<br>Carrier: {carrier_info}"
        folium.Marker([lat, lng], popup=popup_content).add_to(my_map)

        # Save the map as an HTML file
        map_html = my_map.get_root().render()

        context = {
            'map_html': map_html,
            'location': location,
            'carrier_info': carrier_info,
        }

        return render(request, 'phone_location.html', context)

    return render(request, 'home.html')
