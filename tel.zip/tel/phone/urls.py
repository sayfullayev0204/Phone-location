from django.urls import path
from .views import phone_location

urlpatterns = [
    path('', phone_location, name='phone_location'),
]
